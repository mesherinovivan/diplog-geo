<?php

# Load the Ion Auth library when the spark is loaded
$autoload['libraries'] = array();

