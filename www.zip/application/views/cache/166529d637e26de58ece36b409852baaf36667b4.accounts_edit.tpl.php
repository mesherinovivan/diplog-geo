<?php /*%%SmartyHeaderCode:3190552848db0e906b6-48987333%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '166529d637e26de58ece36b409852baaf36667b4' => 
    array (
      0 => 'application\\views\\templates\\accounts_edit.tpl',
      1 => 1384417056,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3190552848db0e906b6-48987333',
  'variables' => 
  array (
    'PAGE_TITLE' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_52848db0f04439_88323896',
  'cache_lifetime' => 86400,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52848db0f04439_88323896')) {function content_52848db0f04439_88323896($_smarty_tpl) {?><!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Контрагенты</title>
</head>
<body>
    <form method="POST" action="save">
        <table>
            <tr>
                <td>Наименование</td>
                <td>
                    <input name = 'Name' type="text"/>
                </td>
            </tr>
            <tr>
                <td>ИНН</td>
                <td>
                    <input name = 'INN' type="text"/>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input name = 'send' type="submit" value="Отправить"/>
                </td>
            </tr>
        </table>
    </form>
</body>
</html><?php }} ?>