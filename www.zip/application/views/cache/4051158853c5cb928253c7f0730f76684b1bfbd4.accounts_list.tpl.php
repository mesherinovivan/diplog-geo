<?php /*%%SmartyHeaderCode:1378252848b7559cbb1-35691741%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4051158853c5cb928253c7f0730f76684b1bfbd4' => 
    array (
      0 => 'application\\views\\templates\\accounts_list.tpl',
      1 => 1384418160,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1378252848b7559cbb1-35691741',
  'variables' => 
  array (
    'PAGE_TITLE' => 0,
    'AccountsData' => 0,
    'iter' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_52848b7564e071_61940483',
  'cache_lifetime' => 86400,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52848b7564e071_61940483')) {function content_52848b7564e071_61940483($_smarty_tpl) {?><!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Контрагенты</title>
</head>
<body>
    

    <div style="background:url(img/AccountsNormal.png) no-repeat; padding-top: 30px; width: 90px; height: 30px; border-radius:10px; border-width: 1px; border-style: solid;border-color: #453678;">Контагенты</div>
    
    <table class="" border=1>
        <tr><td><b>Название</b></td></tr>
        
                      <tr>  <td>Архангельская телевизионная компания</td>  </tr>        
                      <tr>  <td>ЗСО "Телефонная Компания"</td>  </tr>        
                      <tr>  <td>ТСЖ "Малая земля"</td>  </tr>        
                      <tr>  <td>Нижне-скнефтехим-Ойл</td>  </tr>        
                      <tr>  <td>ООО "Современные технологии связи"</td>  </tr>        
                      <tr>  <td>ООО "Центральная" (ООО "Ремстойсервис")</td>  </tr>        
                      <tr>  <td>ООО "НовТелеком"</td>  </tr>        
                      <tr>  <td>СВЯЗИСТ  г. Владимир</td>  </tr>        
                      <tr>  <td>Ростовская Сотовая Связь</td>  </tr>        
                      <tr>  <td>Астрахань-Пейдж</td>  </tr>        
                      <tr>  <td>ЗАО "Престиж Интернет"</td>  </tr>        
                      <tr>  <td>Урал-Интеркард</td>  </tr>        
                      <tr>  <td>Связь объектов транспорта и добычи нефти</td>  </tr>        
                      <tr>  <td>Дальневосточная генерирующая компания</td>  </tr>        
                      <tr>  <td>ООО "Центральная" (ЖЭУ №7)</td>  </tr>        
                      <tr>  <td>СвязьИнформБюро</td>  </tr>        
                      <tr>  <td>РА РТС РОСНЕТ</td>  </tr>        
                      <tr>  <td>КОМСТАР-Регионы Краснодар</td>  </tr>        
                      <tr>  <td>Инфотелеком СП</td>  </tr>        
                      <tr>  <td>Российские железные дороги  г. Владимир</td>  </tr>        
        
    </table>
    <a href="http://www.geo-spd.ru/accounts/welcome/edit">Добавить</a>
</body>
</html><?php }} ?>